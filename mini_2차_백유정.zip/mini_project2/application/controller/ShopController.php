<?php
namespace application\controller;

class ShopController extends Controller {
    public function mainGet() {
        return "main"._EXTENSION_PHP;
    }
}


?>