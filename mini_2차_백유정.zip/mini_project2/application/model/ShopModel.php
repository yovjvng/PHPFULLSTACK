<?php
namespace application\model;

class ShopModel extends Model{
    
}

?>