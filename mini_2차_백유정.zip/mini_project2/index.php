<?php

require_once("application/lib/config.php");// config 파일
require_once("application/lib/autoload.php");// autoload 파일


// require_once("application/lib/application.php"); // application 리콰이어
new application\lib\Application(); // application 호출

?>